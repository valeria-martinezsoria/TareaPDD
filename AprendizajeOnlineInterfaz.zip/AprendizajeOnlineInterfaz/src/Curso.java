public interface Curso {
    void iniciar();
    void completar();
}