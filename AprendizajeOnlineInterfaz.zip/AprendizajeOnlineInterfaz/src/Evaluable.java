public interface Evaluable {
    void calificar(int puntaje);
}