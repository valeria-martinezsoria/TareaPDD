public interface Calificacion {
    void calificar(int estrellas);
}
