public class Main {
    public static void main(String[] args) {

        Cliente cliente = new Cliente("Fulanita");
        Cliente cliente2 = new Cliente("Fulanito");
        Cliente cliente3 = new Cliente("Juan");

        System.out.println("-------------------------------------");

        Hotel hotel = new Hotel("Hotel Elegante");
        Departamento departamento = new Departamento("Calle Bonita #123");
        CasaVacaciones casa = new CasaVacaciones("Playa Paraíso");

        cliente.hacerReserva(hotel, "10 de febrero");
        System.out.println("-------------------------------------");
        cliente2.hacerReserva(departamento, "15 de marzo");
        System.out.println("-------------------------------------");
        cliente3.hacerReserva(casa, "20 de abril");
        System.out.println("-------------------------------------");

        cliente3.cancelarReserva(departamento);

        System.out.println("-------------------------------------");

        cliente2.calificar(hotel, 5);
    }
}