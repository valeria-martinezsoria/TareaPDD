public interface Reservas {
    void reservar(String fecha);
    void cancelarReserva();
}
