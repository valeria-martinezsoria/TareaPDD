package ejercicio7;

public interface Almacenable {
    boolean guardarEnBodega();
    boolean retirarDeBodega();
}
