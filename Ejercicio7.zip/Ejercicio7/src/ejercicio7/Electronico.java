package ejercicio7;

public class Electronico  implements Producto {

    public void obtenerPrecio() {
        System.out.println("Precio del Electronico: 1000 bs");
    }

    public void obtenerStock() {
        System.out.println("Stock del Electronico: 20 electronicos");
    }
}
