package ejercicio7;

public interface Producto {
    void obtenerPrecio();
    void obtenerStock();
}
