package ejercicio7;

public class Ropa implements Producto {
    public void obtenerPrecio() {
        System.out.println("Precio del ropa: 300 bs");
    }

    public void obtenerStock() {
        System.out.println("Stock ropa: 100 prendas");
    }
}
