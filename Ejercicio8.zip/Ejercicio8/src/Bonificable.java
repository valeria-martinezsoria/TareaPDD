public interface Bonificable {
    void calcularBono();
}
