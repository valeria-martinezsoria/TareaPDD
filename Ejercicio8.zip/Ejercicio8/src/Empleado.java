public interface Empleado {

    void calcularSalario();
    void obtenerCargo();
}
