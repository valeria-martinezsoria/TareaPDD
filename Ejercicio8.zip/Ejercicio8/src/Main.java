public class Main {
    public static void main(String[] args) {

        Empresa empresa = new Empresa();
        Administrativo administrativo = new Administrativo(1000);
        Gerente gerente = new Gerente(2000,100);
        Tecnico tecnico = new Tecnico(630);

        empresa.contratarNuevosEmpleados(administrativo);
        empresa.contratarNuevosEmpleados(gerente);
        empresa.contratarNuevosEmpleados(tecnico);

        empresa.personasEnLaEmpresa();

        empresa.despedirEmpleados(tecnico);

        empresa.personasEnLaEmpresa();
    }
}