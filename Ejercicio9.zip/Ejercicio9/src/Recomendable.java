interface Recomendable {
    void obtenerRecomendaciones();
}
