class SistemaRecomendaciones {
    public static void recomendar(Recomendable usuario) {
        usuario.obtenerRecomendaciones();
    }
}

