public class FacturaElectronica implements Facturable{
    public void generarFactura() {
        System.out.println(" se mando al correo una factura electronica");
    }
}
