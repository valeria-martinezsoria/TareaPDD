public class FacturaFisica implements Facturable{
    public void generarFactura() {
        System.out.println("se dio una factura fisica");
    }
}
