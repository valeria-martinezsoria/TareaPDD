public interface Facturable {
    void generarFactura();
}
