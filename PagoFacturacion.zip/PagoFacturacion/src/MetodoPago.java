public interface MetodoPago {
  void procesarPago(double monto);
}
