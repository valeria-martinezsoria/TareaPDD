public class Ciclista implements Repartidor{

    @Override
    public void repartir() {
        System.out.println("Repartir pedido a traves de un ciclista");
    }
}
