//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        System.out.println("RESTAURANT UPB");
        PedidoParaLlevar pedido1 = new PedidoParaLlevar();
        PedidoEnMesa pedido2 = new PedidoEnMesa();

        Motorizado motorizado = new Motorizado(); //simular que un pedido sea enviado por un repartidor motorizado
        Ciclista ciclista = new Ciclista();
        PedidoDomicilio pedido3 = new PedidoDomicilio(motorizado);
        PedidoDomicilio pedido4 = new PedidoDomicilio(ciclista); //simular pedido sera enviado por un repartidor ciclista

        Restaurante restaurante = new Restaurante();


        //agregando los pedidos
        restaurante.recibirPedido(pedido1);
        restaurante.recibirPedido(pedido2);
        restaurante.recibirPedido(pedido3);
        restaurante.recibirPedido(pedido4);


        restaurante.gestionarPedidos();
    }
}
