public class Motorizado implements Repartidor{

    @Override
    public void repartir() {
        System.out.println("Repartidor Motorizado");
    }
}
