public interface Pedido {

    public void preparar();
    public void entregar();
}
