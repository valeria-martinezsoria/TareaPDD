public class PedidoDomicilio implements Pedido {
 Repartidor repartidor; //Como tiene dependecia se lo pone como atributo, composicion

    public PedidoDomicilio(Repartidor repartidor) {
        this.repartidor = repartidor;
    } //como depende de algo se hace un constructor

    @Override
    public void entregar() {
        System.out.println("Entregando pedido domicilio");
        repartidor.repartir();
    }

    @Override
    public void preparar() {
        System.out.println("Preparando pedido domicilio");
    }
}
