public class PedidoParaLlevar implements Pedido{


    public void entregar() {
        System.out.println("Entregando el pedido para llevar");
    }


    public void preparar() {
        System.out.println("Preparando el pedido para llevar");
    }
}
