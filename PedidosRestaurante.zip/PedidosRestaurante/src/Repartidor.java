public interface Repartidor {

    public void repartir();
}
