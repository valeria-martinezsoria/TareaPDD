import java.util.ArrayList;
import java.util.List;

public class Restaurante {

    List<Pedido> pedidos;
    public Restaurante() {
        this.pedidos = new ArrayList<Pedido>();
    }

    public void recibirPedido(Pedido p) {
        this.pedidos.add(p); //.ADD es para pasar a la lista un nuevo pedido
        System.out.println("Tenemos un nuevo pedido");
    }

    public void gestionarPedidos() {
        for (Pedido p : this.pedidos) { //iterar listas, declarar cada item de la lista de pedidos
            p.preparar();
            p.entregar();
            System.out.println("-----------------");
        }
    }
}
