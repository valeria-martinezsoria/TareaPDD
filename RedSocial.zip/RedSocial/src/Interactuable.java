public interface Interactuable {
    void comentar (String comentario);
    void reaccionar (String tipoReaccion);
    void compartir ();
}
