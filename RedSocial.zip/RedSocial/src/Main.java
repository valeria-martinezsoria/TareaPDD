public class Main {
    public static void main(String[] args) {
        System.out.println(" Red Social UPB");
        Foto foto = new Foto();
        Video video = new Video();
        Articulo articulo = new Articulo();
        Usuario usuario = new Usuario(video);
        usuario.interaccion("estaba bueno","like");
    }
}