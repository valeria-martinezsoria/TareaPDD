public interface Conductor {
    void aceptarPasajero();
    void finalizarViaje();
}